package com.MSISDN.MSISDNOperations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsisdnOperationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
