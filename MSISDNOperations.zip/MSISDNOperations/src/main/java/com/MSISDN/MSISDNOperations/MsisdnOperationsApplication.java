package com.MSISDN.MSISDNOperations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsisdnOperationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsisdnOperationsApplication.class, args);
	}

}
